package com.example.springMODEL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringModelApplicationTests {

	@Test
	void contextLoads() {
	}

}
